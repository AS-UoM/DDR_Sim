# generated from colcon_core/shell/template/hook_prepend_value.sh.em

_colcon_prepend_unique_value AMENT_PREFIX_PATH "$COLCON_CURRENT_PREFIX"
