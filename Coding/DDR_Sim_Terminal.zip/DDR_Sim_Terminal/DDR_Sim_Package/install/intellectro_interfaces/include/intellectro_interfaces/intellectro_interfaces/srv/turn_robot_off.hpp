// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef INTELLECTRO_INTERFACES__SRV__TURN_ROBOT_OFF_HPP_
#define INTELLECTRO_INTERFACES__SRV__TURN_ROBOT_OFF_HPP_

#include "intellectro_interfaces/srv/detail/turn_robot_off__struct.hpp"
#include "intellectro_interfaces/srv/detail/turn_robot_off__builder.hpp"
#include "intellectro_interfaces/srv/detail/turn_robot_off__traits.hpp"

#endif  // INTELLECTRO_INTERFACES__SRV__TURN_ROBOT_OFF_HPP_
