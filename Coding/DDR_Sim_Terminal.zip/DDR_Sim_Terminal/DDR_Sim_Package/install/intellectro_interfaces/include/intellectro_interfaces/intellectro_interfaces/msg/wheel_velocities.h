// generated from rosidl_generator_c/resource/idl.h.em
// with input from intellectro_interfaces:msg/WheelVelocities.idl
// generated code does not contain a copyright notice

#ifndef INTELLECTRO_INTERFACES__MSG__WHEEL_VELOCITIES_H_
#define INTELLECTRO_INTERFACES__MSG__WHEEL_VELOCITIES_H_

#include "intellectro_interfaces/msg/detail/wheel_velocities__struct.h"
#include "intellectro_interfaces/msg/detail/wheel_velocities__functions.h"
#include "intellectro_interfaces/msg/detail/wheel_velocities__type_support.h"

#endif  // INTELLECTRO_INTERFACES__MSG__WHEEL_VELOCITIES_H_
