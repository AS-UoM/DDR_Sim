// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef INTELLECTRO_INTERFACES__SRV__TURN_ROBOT_ON_HPP_
#define INTELLECTRO_INTERFACES__SRV__TURN_ROBOT_ON_HPP_

#include "intellectro_interfaces/srv/detail/turn_robot_on__struct.hpp"
#include "intellectro_interfaces/srv/detail/turn_robot_on__builder.hpp"
#include "intellectro_interfaces/srv/detail/turn_robot_on__traits.hpp"

#endif  // INTELLECTRO_INTERFACES__SRV__TURN_ROBOT_ON_HPP_
