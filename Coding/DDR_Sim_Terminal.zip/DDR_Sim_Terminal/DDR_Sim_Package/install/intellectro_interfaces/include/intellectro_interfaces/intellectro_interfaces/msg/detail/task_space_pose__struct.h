// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from intellectro_interfaces:msg/TaskSpacePose.idl
// generated code does not contain a copyright notice

#ifndef INTELLECTRO_INTERFACES__MSG__DETAIL__TASK_SPACE_POSE__STRUCT_H_
#define INTELLECTRO_INTERFACES__MSG__DETAIL__TASK_SPACE_POSE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/TaskSpacePose in the package intellectro_interfaces.
typedef struct intellectro_interfaces__msg__TaskSpacePose
{
  double x;
  double y;
  double phi_z;
} intellectro_interfaces__msg__TaskSpacePose;

// Struct for a sequence of intellectro_interfaces__msg__TaskSpacePose.
typedef struct intellectro_interfaces__msg__TaskSpacePose__Sequence
{
  intellectro_interfaces__msg__TaskSpacePose * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} intellectro_interfaces__msg__TaskSpacePose__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // INTELLECTRO_INTERFACES__MSG__DETAIL__TASK_SPACE_POSE__STRUCT_H_
