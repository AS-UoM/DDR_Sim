// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from intellectro_interfaces:srv/TurnRobotOff.idl
// generated code does not contain a copyright notice

#ifndef INTELLECTRO_INTERFACES__SRV__DETAIL__TURN_ROBOT_OFF__BUILDER_HPP_
#define INTELLECTRO_INTERFACES__SRV__DETAIL__TURN_ROBOT_OFF__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "intellectro_interfaces/srv/detail/turn_robot_off__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace intellectro_interfaces
{

namespace srv
{


}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::intellectro_interfaces::srv::TurnRobotOff_Request>()
{
  return ::intellectro_interfaces::srv::TurnRobotOff_Request(rosidl_runtime_cpp::MessageInitialization::ZERO);
}

}  // namespace intellectro_interfaces


namespace intellectro_interfaces
{

namespace srv
{

namespace builder
{

class Init_TurnRobotOff_Response_success
{
public:
  Init_TurnRobotOff_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::intellectro_interfaces::srv::TurnRobotOff_Response success(::intellectro_interfaces::srv::TurnRobotOff_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return std::move(msg_);
  }

private:
  ::intellectro_interfaces::srv::TurnRobotOff_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::intellectro_interfaces::srv::TurnRobotOff_Response>()
{
  return intellectro_interfaces::srv::builder::Init_TurnRobotOff_Response_success();
}

}  // namespace intellectro_interfaces

#endif  // INTELLECTRO_INTERFACES__SRV__DETAIL__TURN_ROBOT_OFF__BUILDER_HPP_
