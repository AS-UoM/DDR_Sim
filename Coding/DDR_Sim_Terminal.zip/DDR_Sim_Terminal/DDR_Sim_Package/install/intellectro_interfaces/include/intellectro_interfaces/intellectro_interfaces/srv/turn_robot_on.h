// generated from rosidl_generator_c/resource/idl.h.em
// with input from intellectro_interfaces:srv/TurnRobotOn.idl
// generated code does not contain a copyright notice

#ifndef INTELLECTRO_INTERFACES__SRV__TURN_ROBOT_ON_H_
#define INTELLECTRO_INTERFACES__SRV__TURN_ROBOT_ON_H_

#include "intellectro_interfaces/srv/detail/turn_robot_on__struct.h"
#include "intellectro_interfaces/srv/detail/turn_robot_on__functions.h"
#include "intellectro_interfaces/srv/detail/turn_robot_on__type_support.h"

#endif  // INTELLECTRO_INTERFACES__SRV__TURN_ROBOT_ON_H_
