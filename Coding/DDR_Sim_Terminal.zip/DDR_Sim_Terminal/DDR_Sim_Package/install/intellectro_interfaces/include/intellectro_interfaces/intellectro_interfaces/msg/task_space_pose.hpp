// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef INTELLECTRO_INTERFACES__MSG__TASK_SPACE_POSE_HPP_
#define INTELLECTRO_INTERFACES__MSG__TASK_SPACE_POSE_HPP_

#include "intellectro_interfaces/msg/detail/task_space_pose__struct.hpp"
#include "intellectro_interfaces/msg/detail/task_space_pose__builder.hpp"
#include "intellectro_interfaces/msg/detail/task_space_pose__traits.hpp"

#endif  // INTELLECTRO_INTERFACES__MSG__TASK_SPACE_POSE_HPP_
