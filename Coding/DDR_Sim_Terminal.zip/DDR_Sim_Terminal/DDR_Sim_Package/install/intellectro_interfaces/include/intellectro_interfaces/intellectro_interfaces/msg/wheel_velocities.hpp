// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef INTELLECTRO_INTERFACES__MSG__WHEEL_VELOCITIES_HPP_
#define INTELLECTRO_INTERFACES__MSG__WHEEL_VELOCITIES_HPP_

#include "intellectro_interfaces/msg/detail/wheel_velocities__struct.hpp"
#include "intellectro_interfaces/msg/detail/wheel_velocities__builder.hpp"
#include "intellectro_interfaces/msg/detail/wheel_velocities__traits.hpp"

#endif  // INTELLECTRO_INTERFACES__MSG__WHEEL_VELOCITIES_HPP_
