""" Imports include rclpy to provide ROS2 compatibility and allow the creation
    of a node and include Future in order to create and use ROS2 clients.
    The Python Math library is used to access the cos() and sin() functions.
    Intellectro package interface messages and services are imported to allow
    communication between nodes. """
import rclpy
import math
from rclpy.task import Future
from rclpy.node import Node
from intellectro_interfaces.srv import TurnRobotOff
from intellectro_interfaces.srv import TurnRobotOn
from intellectro_interfaces.msg import TaskSpacePose
from intellectro_interfaces.msg import WheelVelocities


class IntellectroControllerNode(Node):
    """ Initialisation of IntellectroControllerNode with clients, publishers/subscribers
        and variables. """

    def __init__(self):

        super().__init__('intellectro_controller')

        # Initialisation of robot state as OFF to be altered in a response from IntellectroNode
        self.robot_state = "OFF"

        # Initialisation of wheel velocities message for the wheel velocities publisher
        self.msg = WheelVelocities()

        # Robot on signal client using 'turn_robot_on' service
        self.turn_robot_on = self.create_client(
            srv_type=TurnRobotOn,
            srv_name='intellectro/turn_robot_on')

        # Robot off signal client using 'turn_robot_off' service
        self.turn_robot_off = self.create_client(
            srv_type=TurnRobotOff,
            srv_name='intellectro/turn_robot_off')

        # Wheel velocities publisher using 'wheel_velocities' message
        self.wheel_velocities_publisher = self.create_publisher(
            msg_type=WheelVelocities,
            topic='intellectro/wheel_velocities',
            qos_profile=1)

        # Task space pose subscriber using 'task_space_pose' message
        self.task_space_pose_subscriber = self.create_subscription(
            msg_type=TaskSpacePose,
            topic='intellectro/task_space_pose',
            callback=self.task_space_pose_callback,
            qos_profile=1)

        # Waits for service to become available before requesting the turn_robot_on service
        while not self.turn_robot_on.wait_for_service(timeout_sec=1.0):
            self.get_logger().info(f'Service {self.turn_robot_on.srv_name} not available, waiting...')
        request = TurnRobotOn.Request()

        # Creates a request to the turn_robot_on service
        self.future = self.turn_robot_on.call_async(request)
        # Runs the intellectro_on_response function after receiving a response from the turn_robot_on service
        self.future.add_done_callback(self.intellectro_on_response)

    """ 'intellectro_on_response':
            This function processes the response from the IntellectroNode node's turn on server, changing the
            state variable in the controller node to match the state variable stored in the IntellectroNode node. It 
            uses the equation, radius * (pi * 178.0/180.0) / 20.0 to set the velocity of the two wheels to rotate at
            velocities which turn the robot the required 178 degrees over 20 seconds. The left wheel's velocity is in 
            the opposite direction to the right wheel (negative). It then uses the intellectro_set_velocities function.
            It also provides information to the operator telling them the robot has been successfully turned on. """

    def intellectro_on_response(self, future: Future):

        response = future.result()

        if response:

            if self.robot_state == "OFF":
                self.robot_state = "ON"
                self.get_logger().info("ROBOT TURNED ON SUCCESSFULLY. SENDING WHEEL VELOCITIES.")
                # Velocities required to set the robot to turn 178.0 degrees (converted to radians) over 20 seconds
                vr = 0.08 * (math.pi * (178.0 / 180.0)) / 20.0
                vl = -0.08 * (math.pi * (178.0 / 180.0)) / 20.0
                # Used to set robot wheel velocities
                self.msg.right_wheel_velocity = vr
                self.msg.left_wheel_velocity = vl
                self.wheel_velocities_publisher.publish(self.msg)
        else:

            self.get_logger().info("ROBOT NOT TURNED ON.")

    """ 'intellectro_off_response':
        This function processes the response from the IntellectroNode node's turn off server, changing the
        state variable in the controller node to match the state variable stored in the IntellectroNode node. It 
        also provides information to the operator telling them that the robot has been successfully turned off. """

    def intellectro_off_response(self, future: Future):
        response = future.result()

        if response:
            self.robot_state = "OFF"
            self.get_logger().info("ROBOT TURNED OFF SUCCESSFULLY.")
        else:
            self.get_logger().info("ROBOT NOT TURNED ON.")

    """ task_space_pose_callback:
        This function controls the transition from the rotational motion of the robot to linear motion, providing 
        the required wheel velocities for linear motion of 1 meter after checking to make sure the rotation is complete.
        Every time the callback runs, it reads the current position, checks to see if the robot is still rotating by
        checking the x and y position, changing the velocity to the required velocity to travel 1 meter in 20 seconds.
        Once the robot reaches the 1 meter distance it sets the wheel velocities to zero, publishes those velocities
        to the IntellectroNode node to stop the robot and then requests the robot to turn off. """

    def task_space_pose_callback(self, msg: TaskSpacePose):

        if msg.x > -0.0001:
            if msg.phi_z < math.pi * (178.0 / 180.0):
                pass
            else:
                # Velocities required to set the robot moving forwards 1 meter in 20 seconds
                self.msg.right_wheel_velocity = 1.0 / 20.0
                self.msg.left_wheel_velocity = 1.0 / 20.0
                self.wheel_velocities_publisher.publish(self.msg)

        # Checks to ensure the robot has reached the correct position and then stops and turns off the robot
        if msg.x < (math.cos(math.pi * 178.0 / 180.0) + 0.001):
            self.msg.right_wheel_velocity = 0.0
            self.msg.left_wheel_velocity = 0.0
            self.wheel_velocities_publisher.publish(self.msg)
            # Turn off request is created and turn_robot_off is requested
            request = TurnRobotOff.Request()
            self.future = self.turn_robot_off.call_async(request)
            self.future.add_done_callback(self.intellectro_off_response)


""" The main function initialises rclpy, creates an instance of the IntellectroControllerNode node
    and repeatedly runs through the node. If a keyboard interrupt is pressed, the node
    cleanly stops. """


def main(args=None):
    try:
        rclpy.init(args=args)
        intellectro_controller = IntellectroControllerNode()
        rclpy.spin(intellectro_controller)

    except KeyboardInterrupt:
        pass
    except Exception as e:
        print(e)


if __name__ == '__main__':
    main()
