""" Imports include rclpy to provide ROS2 compatibility.
    The Python Math library is used to access the cos() and sin() functions.
    Intellectro package interface messages and services are imported to allow
    communication between nodes. """
import rclpy
import math
from rclpy.node import Node
from intellectro_interfaces.srv import TurnRobotOff
from intellectro_interfaces.srv import TurnRobotOn
from intellectro_interfaces.msg import TaskSpacePose
from intellectro_interfaces.msg import WheelVelocities


class IntellectroNode(Node):
    """ Initialisation of IntellectroNode with servers, publishers/subscribers
        and variables. """

    def __init__(self):

        super().__init__('intellectro_node')

        # Initialise robot states, two states, "OFF" and "ON"
        self.robot_state = "OFF"
        # Initialise robot pose x(t) as x_t of type TaskSpacePose message
        self.x_t = TaskSpacePose()
        self.x_t.x = 0.0
        self.x_t.y = 0.0
        self.x_t.phi_z = 0.0
        # Initialise tau
        self.tau = 0.01
        # Wheel radius 'r', and distance between wheels 'l', hard coded
        self.r = 0.08
        self.l = 0.16
        # Initial wheel velocities vr and vl
        self.vr = 0.0
        self.vl = 0.0
        # Define wheel maximum velocity and minimum velocity
        self.vmax = 0.1
        self.vmin = -0.1
        # Initialise current time
        self.t = 0.0
        # Defined required angle for rotational movement (178.0 degrees converted to radians)
        self.required_angle = math.pi * 178.0 / 180.0
        # Defined required distance for linear movement (1.0 meters)
        self.required_distance = 1.0
        # Scaler for 10Hz publisher
        self.scaler_counter = 0

        # Server, publisher and subscriber creation
        # Robot on signal server using 'turn_robot_on' service and callback
        self.turn_robot_on = self.create_service(
            srv_type=TurnRobotOn,
            srv_name='intellectro/turn_robot_on',
            callback=self.turn_robot_on_callback)
        # Robot off signal server using 'turn_robot_off' service and callback
        self.turn_robot_off = self.create_service(
            srv_type=TurnRobotOff,
            srv_name='intellectro/turn_robot_off',
            callback=self.turn_robot_off_callback)
        # Task space pose publisher using 'task_space_pose' message
        self.task_space_pose = self.create_publisher(
            msg_type=TaskSpacePose,
            topic='intellectro/task_space_pose',
            qos_profile=1)
        # Wheel velocities subscriber using 'wheel_velocities' message and callback
        self.wheel_velocities = self.create_subscription(
            msg_type=WheelVelocities,
            topic='intellectro/wheel_velocities',
            callback=self.wheel_velocities_callback,
            qos_profile=1)

        # A timer is created which updates task_space_pose every 0.1 seconds (10 Hz)
        self.timer = self.create_timer(self.tau, self.task_space_pose_callback)

    """ 'turn_robot_on_callback':
        When this callback function is called by the controller node, if the current state of the robot
        is 'OFF', it changes the robot's state to 'ON', sends an informative notification to
        the terminal and sets the 'success' field of the TurnRobotOn service response to True. 
        If the current state is 'ON', info is sent to the terminal and the response field is set to False.
        The current status is displayed in the terminal to inform the operator. """

    def turn_robot_on_callback(self,
                               request: TurnRobotOn.Request,
                               response: TurnRobotOn.Response) -> TurnRobotOn.Response:
        if self.robot_state == "OFF":
            self.robot_state = "ON"
            self.get_logger().info("Turning robot on.")
            response.success = True
        elif self.robot_state == "ON":
            self.get_logger().info("Robot already on.")
            response.success = False

        # State information for the operator
        if self.robot_state == "ON":
            self.get_logger().info("Robot current state == ON.")
        elif self.robot_state == "OFF":
            self.get_logger().info("Robot current state == OFF.")
        return response

    """ 'turn_robot_off_callback':
        Functions similarly to the 'turn_robot_on' callback but responds with True when the robot is
        'ON', changes the state to 'OFF', and sends information to the terminal. """

    def turn_robot_off_callback(self,
                                request: TurnRobotOff.Request,
                                response: TurnRobotOff.Response) -> TurnRobotOff.Response:
        if self.robot_state == "ON":
            self.robot_state = "OFF"
            self.get_logger().info("Turning robot off.")
            self.vr = 0.0
            self.vl = 0.0
            response.success = True
        elif self.robot_state == "OFF":
            self.get_logger().info("Robot already off.")
            response.success = False

        # State information for the operator
        if self.robot_state == "ON":
            self.get_logger().info("Robot current state == ON.")
        elif self.robot_state == "OFF":
            self.get_logger().info("Robot current state == OFF.")

        return response

    """ 'task_space_pose_callback':
        When called every 0.1 seconds, if the state is 'OFF', the wheel velocities
        vr and vl are set to 0.0. If the robot state is set to 'ON', the motion of the robot is calculated
        over the time period using the differential drive kinematic equations and published to the message x_t
        (representing pose x(t)) using message type TaskSpacePose. """

    def task_space_pose_callback(self):

        if self.robot_state == "ON":
            # Increase scaler counter
            self.scaler_counter = self.scaler_counter + 1
            if self.scaler_counter < 10:
                # Calculate linear velocity (wheel velocities cancel out if rotating on a point)
                v = (self.vr + self.vl) / 2.0
                # Calculate rotational velocity (zero if both wheels are rotating at the same velocity)
                phi_z_dot = (self.vr - self.vl) / self.l
                # Calculate angle from old angle + rotational velocity * sampling time
                self.x_t.phi_z = self.x_t.phi_z + phi_z_dot * self.tau
                # Calculate x-position from old position + linear velocity * cos(angle) * 0.01
                self.x_t.x = self.x_t.x + v * math.cos(self.x_t.phi_z) * self.tau
                # Calculate y-position from old position + linear velocity * sin(angle) * 0.01
                self.x_t.y = self.x_t.y + v * math.sin(self.x_t.phi_z) * self.tau
                # Update time elapsed
                self.t = self.t + self.tau
            else:
                # Publish new x(t) pose
                self.task_space_pose.publish(self.x_t)
                # Reset scaler counter
                self.scaler_counter = 0
        elif self.robot_state == "OFF":
            self.vr = 0.0
            self.vl = 0.0

    """ 'wheel_velocities_callback':
        This callback function receives the wheel velocity values using the WheelVelocities message type and
        clamps them to be within the boundary of -0.1 and 0.1 by setting the values outside of this range to the
        boundaries. """

    def wheel_velocities_callback(self, msg: WheelVelocities):
        if self.robot_state == "OFF":
            pass
        elif self.robot_state == "ON":
            self.vr = msg.right_wheel_velocity
            if self.vr < self.vmin:
                self.vr = -0.1
            if self.vr > self.vmax:
                self.vr = 0.1
            self.vl = msg.left_wheel_velocity
            if self.vl < self.vmin:
                self.vl = -0.1
            if self.vl > self.vmax:
                self.vl = 0.1
            # Information on time, position, angle and wheel velocity published by task_space_pose publisher
            # Displaying information only when the wheel velocity changes reduces unnecessary printed output
            # Real-time x(t) can be tracked using 'ros2 topic echo intellectro/task_space_pose' in the terminal
            self.get_logger().info(f'Current time == {self.t} seconds')
            self.get_logger().info(f'Current x-position == {self.x_t.x} m')
            self.get_logger().info(f'Current y-position == {self.x_t.y} m')
            self.get_logger().info(f'Current angle == {self.x_t.phi_z} radians')
            self.get_logger().info(f'Right wheel velocity == {self.vr} m/s')
            self.get_logger().info(f'Left wheel velocity == {self.vl} m/s')


""" The main function initialises rclpy, creates an instance of the IntellectroNode node
    and repeatedly runs through the node. If a keyboard interrupt is pressed, the node
    cleanly stops. """


def main(args=None):
    try:
        rclpy.init(args=args)
        intellectro_node = IntellectroNode()
        rclpy.spin(intellectro_node)

    except KeyboardInterrupt:
        pass
    except Exception as e:
        print(e)


if __name__ == '__main__':
    main()
